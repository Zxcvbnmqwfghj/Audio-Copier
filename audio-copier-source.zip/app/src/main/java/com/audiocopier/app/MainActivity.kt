package com.audiocopier.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.audiocopier.app.ui.FoundationScreen
import com.audiocopier.app.ui.theme.AudioCopierTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AudioCopierTheme {
                FoundationScreen()
            }
        }
    }
}
